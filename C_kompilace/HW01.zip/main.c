#include <stdio.h>

int a;
int b;
int err;

void Response() {
  printf("Desitkova soustava: %d %d\n", a, b);
  printf("Sestnactkova soustava: %x %x\n", a, b);
  printf("Soucet: %d + %d = %d\n", a, b, a + b);
  printf("Rozdil: %d - %d = %d\n", a, b, a - b);
  printf("Soucin: %d * %d = %d\n", a, b, a * b);
  if (b != 0) {
    printf("Podil: %d / %d = %d\n", a, b, a / b);
  } else {
    printf("Podil: %d / %d = NaN\n", a, b);
  }
  float w = (a + b) * 1.0f / 2;
  printf("Prumer: %.1f\n", w);
}

int main(void) {
  scanf("%d %d", &a, &b);
  if (a < -10000 || a > 10000 || b < -10000 || b > 10000) {
    fprintf(stderr, "Error: Vstup je mimo interval!\n");
    return 100;
  }
  Response();
  if (b == 0) {
    fprintf(stderr, "Error: Nedefinovany vysledek!\n");
    return 101;
  }
  return 0;
}